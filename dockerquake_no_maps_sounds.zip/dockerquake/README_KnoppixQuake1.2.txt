Why is this called KnoppixQuake?
Well, because I created a bootable linux distro way back based off Morphix,
which was based on Knoppix, to have a bootable Quake TF server.
I resurrected it and got it running on a docker container, and here we are.

----------
Original KnoppixQuake README...

I'll keep this short and sweet.

There are some extra files laying around from when this was the old 
Open Port Quake Server.  I used to work there, and we had a Quake Server
that ran every day from Noon - 12:30.  It was a hoot.  We even had our own
map of the floor of our building.  It is called opt084 if you want to check
it out.  There are also two other maps worth mentioning:  jtower and
flyworld2.  Jtower was created by a coworker at OPT, and it pretty fun.  I 
don't think it has been released into the wild, until now.  Flyworld2 is a map
that I created.  It was created with the hope that no class would have a 
specific advantage.  It is different than most maps, no flag, 4 teams, and
a few surprises.  Play it with sv_gravity set to 150, it makes it a little
more interesting.

RIP Open Port Technology, and the Quake Server that was the source of many 
good times.

---

qwsv is the Quake Server binary.

I have provided a start script, called startquake, that should explain itself.
It runs the server in console mode.  It reads server.cfg, if you want to tweak
anything in this file, feel free.  All of the maps are in fortress/maps/.  Note
that when you start the server, you want to give it the gamedir of "fortress".

If you want to change a map, you can just 
type "map <mapname>" (no bsp extension necessary) in the console window.  
If you want to do it from your Quake client, go to the command line after you 
have connected to the server and type "rcon flyworld map <mapname>".

Since the filesystem is read only, you cannot change the server.cfg file, but 
you can change things from the console, and from the client.
For example, you probably want to change the rcon password after you start
the server.  If you wanted to change it to "notacamper", you would type in 
the console window "rcon_password notacamper".
****
NOTE:
The filesystem isn't read only anymore, but I have left the above section in for
informational purposes.  You should be able to modify/save the server.cfg file.
You may have to be root or sudo to do it.
****

By default, the map will cycle between flyworld2 with low gravity, and flyworld2 
with normal gravity.  The default value for sv_gravity is 800, and I have the 
low set to 150.  You can see this in the fortress/cycle directory, there is a cfg
file for each map.  If you want to change the gravity, or any other setting, you
can do so at the console.  See the following examples for what to type in the 
console.

Gravity
-------
sv_gravity 800 (default)
sv_gravity 150 (a good setting for flyworld2)

Change Map
----------
map jtower1	(jtower, created by an ex-Open Port employee)
map opt084	(the floor layout of our old building - only fun if you worked there)

Time Limit
----------
timelimit 30	(in minutes.  It is currently set to 30)

Cycle
-----
When the timelimit expires, the server goes to the next cfg file in the 
qwmcycle directory.  Because the system is read only, you can't change this.
Note that the cfg files in there set the gravity, so when it changes you may 
need to reset it at the console, and change to a different map if you like.

Your Own Files
--------------
If you want to create your own server.cfg file, or your own startup script,
you can do that.  You will need to put it on a floppy disk.
cd /quake
cp startquake /mnt/auto/floppy
cp fortress/server.cfg /mnt/auto/floppy

Now edit the files (if you don't know vi, you'll have to edit the files on
another machine or something)

Here is the format for using your own cfg file from a floppy:
./qwsv +gamedir fortress +exec ../../../mnt/auto/floppy/yourconfig.cfg

The exec command doesn't accept the direct path, so you have to back out of
the current path to get there.

If you want to make your own startup script, make sure to cd to /quake before
running it, and always use +gamedir fortress so it can find the right files.

OR....

If you have enough memory (at least 150MB, if you want all the maps) you can 
copy everything to the ramdisk.  Type "df -akh" and see if you have at least 
150MB free for /ramdisk.
If you do, then "cp -a /KNOPPIX/quake /tmp" and "cd /tmp/quake".  Edit the
files and run the server from there.  If you don't have 150MB, you may be able
to copy everything except the maps, and then copy the few maps you want to
play to the ramdisk.  You'll have to experiment with that.

****
NOTE: I don't believe this is the case anymore, you should be able to modify
files as they are. (as root or sudo)
****

Shaka Custom TF 3.2  (new add-on, as of 12-27-03)
http://www.telefragged.com/shaka/
-------------------
Someone requested that I get Shaka Custom TF working.  
It is included now with the distro, there is a readme for it as well.
You can switch back and forth between MegaTF and CustomTF easily.

That's about it.  Have fun...
