This is the hack to allow you to play Shaka Custom TF on 
KnoppixQuake.  KnoppixQuake was set up to play MegaTF, but I 
hacked this together to allow you to play Custom TF as well.

This archive contains all of the files needed to play CustomTF
on the KnoppixQuake CD.  This includes some basic scripts to 
configure the server for either Shaka Custom TF or Mega TF.

megatf-to-shaka:
Sets up the server for Shaka Custom TF

shaka-to-megatf:
Switches the server back from Shaka to MegaTF

qwsv.shaka is the server binary you need to run for CustomTF, but
there is a start file that helps with this: startquake.shaka

Any questions, feel free to email me:  superflytnt@earthlink.net

SuperFlyTNT...

http://knoppixquake.webhop.net
